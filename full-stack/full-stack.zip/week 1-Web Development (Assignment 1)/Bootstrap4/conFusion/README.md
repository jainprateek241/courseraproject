# Project 1

#### First js for bootstrap course

[![LARGE SCREEN](https://github.com/kolldavi/fullstack-coursera/blob/master/bootstrapCourse/Bootstrap4/conFusion/largScreenshot.png?raw=true)]

[![XSMALL SCREEN](https://github.com/kolldavi/fullstack-coursera/blob/master/bootstrapCourse/Bootstrap4/conFusion/xtraSmallScreenShot.png?raw=true)]